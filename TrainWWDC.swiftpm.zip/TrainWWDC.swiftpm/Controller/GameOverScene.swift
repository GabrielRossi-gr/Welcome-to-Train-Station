//
//  GameOverScene.swift
//  TrainWWDC
//
//  Created by Gabriel Rossi on 31/01/24.
//

import Foundation
import SpriteKit

class GameOverScene: SKScene {
    
    
    
    
    override func sceneDidLoad() {
    }

}
