//
//  TutorialData.swift
//  TrainWWDC
//
//  Created by Gabriel Rossi on 20/02/24.
//

import Foundation
import SpriteKit

class TutorialData {
    
    init(){
        
    }
    
    public static func getImages() -> [String]{
        let images = [
            "TutorialIMG0",
            "TutorialIMG1",
            "TutorialIMG2",
            "TutorialIMG3",
            "TutorialIMG4"

        ]
        return images
    }
    
    
    
}
